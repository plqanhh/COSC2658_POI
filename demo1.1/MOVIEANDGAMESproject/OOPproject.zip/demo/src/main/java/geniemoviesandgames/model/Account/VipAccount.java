package geniemoviesandgames.model.Account;

import geniemoviesandgames.model.Account.GuestAccount;
import geniemoviesandgames.model.Account.RegularAccount;
import geniemoviesandgames.model.Item.Item;

import java.util.ArrayList;

public class VipAccount extends GuestAccount {
    private int freeRent=0;
    private int pointRewards=0;
    final int pointRewardsForfreeRent =100;
    final int pointRewardsEachReturn =10;
    
    /**
     * @return int return the freeRent
     */
    public int getFreeRent() {
        return freeRent;
    }

    /**
     * @param freeRent the freeRent to set
     */
    public void setFreeRent(int freeRent) {
        this.freeRent = freeRent;
    }

    /**
     * @return int return the pointRewards
     */
    public int getPointRewards() {
        return pointRewards;
    }

    /**
     * @param pointRewards the pointRewards to set
     */
    public void setPointRewards(int pointRewards) {
        this.pointRewards = pointRewards;
    }
    public VipAccount(){
        super();
    }
    public VipAccount(String ID, String name, String address, int phone, ArrayList<Item> rentals, String username, String password){
        super(ID, name, address, phone, rentals, username, password);
    }
    public VipAccount(RegularAccount acc){

        setCustomerAddress(acc.getCustomerAddress());
        setCustomerFullname(acc.getCustomerFullname());
        setCustomerID(acc.getCustomerID());
        setCustomerPassWord(acc.getCustomerPassWord());
        setCustomerPhone(acc.getCustomerPhone());
        setCustomerUsername(acc.getCustomerUsername());
        setCustomerListofRentals(acc.getCustomerListofRentals());
        setItemReturned(acc.getItemReturned());
        setitemBorrow(acc.getitemBorrow());
        setFreeRent(0);
        setPointRewards(0);
    }
}
