package geniemoviesandgames.controller;

import geniemoviesandgames.Switchingscence;



public class adminController extends Switchingscence{
    
}
