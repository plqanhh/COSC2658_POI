package geniemoviesandgames.model.Account;

import geniemoviesandgames.model.Account.GuestAccount;
import geniemoviesandgames.model.Item.Item;

import java.util.ArrayList;

public class RegularAccount extends GuestAccount {

    
    int itemReturnedToPromote =5;
    public RegularAccount(){
        super();
    }
    public RegularAccount(String ID, String name, String address, int phone, ArrayList<Item> rentals, String username, String password){
        super(ID, name, address, phone, rentals, username, password);
    }
    
    
    public RegularAccount(GuestAccount acc){
        setCustomerAddress(acc.getCustomerAddress());
        setCustomerFullname(acc.getCustomerFullname());
        setCustomerID(acc.getCustomerID());
        setCustomerPassWord(acc.getCustomerPassWord());
        setCustomerPhone(acc.getCustomerPhone());
        setCustomerUsername(acc.getCustomerUsername());
        setCustomerListofRentals(acc.getCustomerListofRentals());
        setItemReturned(acc.getItemReturned());
        setitemBorrow(acc.getitemBorrow());
    } 
}
