package geniemoviesandgames.model.Item;

public class OMRecord extends Item {
    public OMRecord(String itemID, String itemTitle, String rentalType, String loanType, int stock, double rentalFee, String rentalStatus, String genre) {
        super(itemID, itemTitle, rentalType, loanType, stock, rentalFee, rentalStatus, genre);
        this.genre = genre;
    }
}
