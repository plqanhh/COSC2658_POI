package geniemoviesandgames.model.Account;

public class AdminAccount {
    public static void main(String[] args) {

    }
}
