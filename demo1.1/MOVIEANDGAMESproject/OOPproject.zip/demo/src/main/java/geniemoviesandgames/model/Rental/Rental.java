package geniemoviesandgames.model.Rental;

import geniemoviesandgames.model.Account.Account;
import geniemoviesandgames.model.Item.Item;

public class Rental {
    private String rentalID;
    private Account customer;
    private Item item;

    public Rental(String rentalID, Account customer, Item item) {
        this.rentalID = rentalID;
        this.customer = customer;
        this.item = item;
    }

    public String getRentalID() {
        return rentalID;
    }

    public void setRentalID(String rentalID) {
        this.rentalID = rentalID;
    }

    public Account getCustomer() {
        return customer;
    }

    public void setCustomer(Account customer) {
        this.customer = customer;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public void rentOut() {
        if (item.getRentalStatus() == RentalStatus.AVAILABLE && item.getStock() > 0) {
            item.setRentalStatus(RentalStatus.BORROWED);
            item.setStock(item.getStock() - 1);
        }
    }

    public void returnItem() {
        if (item.getRentalStatus() == RentalStatus.BORROWED) {
            item.setRentalStatus(RentalStatus.AVAILABLE);
            item.setStock(item.getStock() + 1);
        }
    }
}