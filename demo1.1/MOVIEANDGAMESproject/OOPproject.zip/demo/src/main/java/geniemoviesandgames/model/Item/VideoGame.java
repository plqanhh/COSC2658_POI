package geniemoviesandgames.model.Item;

public class VideoGame extends Item {
    public VideoGame(String itemID, String itemTitle, String rentalType, String loanType, int stock, double rentalFee, String rentalStatus, String genre) {
        super(itemID, itemTitle, rentalType, loanType, stock, rentalFee, rentalStatus, genre);
        this.genre = null;
    }
}