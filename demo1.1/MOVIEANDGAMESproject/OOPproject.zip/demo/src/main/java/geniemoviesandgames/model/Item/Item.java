package geniemoviesandgames.model.Item;

import java.util.Arrays;
import java.util.List;

public class Item {
    protected static final String[] rentalTypes = {"Record", "DVD", "Game"};
    protected static final String[] loanTypes = {"2-day loan", "1-week"};
    protected static final String[] rentalStatuses = {"Borrowed", "Available"};
    protected static String[] genres = {"Action", "Horror", "Drama", "Comedy"};
    protected String itemID;
    protected String itemTitle;
    protected String rentalType;
    protected String loanType;
    protected int stock;
    protected double rentalFee;
    protected String rentalStatus;
    protected String genre;

    public Item(String itemID, String itemTitle, String rentalType, String loanType, int stock, double rentalFee, String rentalStatus, String genre) {
        this.itemID = itemID;
        this.itemTitle = itemTitle;
        this.rentalType = rentalType;
        this.loanType = loanType;
        this.stock = stock;
        this.rentalFee = rentalFee;
        this.rentalStatus = rentalStatus;
        this.genre = genre;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public String getItemTitle() {
        return itemTitle;
    }

    public void setItemTitle(String itemTitle) {
        this.itemTitle = itemTitle;
    }

    public String getRentalType() {
        return rentalType;
    }

    public void setRentalType(String rentalType) {
        this.rentalType = rentalType;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double getRentalFee() {
        return rentalFee;
    }

    public void setRentalFee(double rentalFee) {
        this.rentalFee = rentalFee;
    }

    public String getRentalStatus() {
        return rentalStatus;
    }

    public void setRentalStatus(String rentalStatus) {
        this.rentalStatus = rentalStatus;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
}
