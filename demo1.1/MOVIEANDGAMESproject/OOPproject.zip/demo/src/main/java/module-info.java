module geniemoviesandgames {
    requires javafx.controls;
    requires javafx.fxml;

    opens geniemoviesandgames to javafx.fxml;
    exports geniemoviesandgames;
    
    opens geniemoviesandgames.controller to javafx.fxml;
    exports geniemoviesandgames.controller;

    opens geniemoviesandgames.model to javafx.fxml;
    exports geniemoviesandgames.model;
    opens geniemoviesandgames.model.Item to javafx.fxml;
    exports geniemoviesandgames.model.Item;
    opens geniemoviesandgames.model.Account to javafx.fxml;
    exports geniemoviesandgames.model.Account;
    exports geniemoviesandgames.model.Rental;
    opens geniemoviesandgames.model.Rental to javafx.fxml;
}
